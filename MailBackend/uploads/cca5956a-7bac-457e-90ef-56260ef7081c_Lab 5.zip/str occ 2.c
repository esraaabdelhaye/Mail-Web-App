#include <stdio.h>
#include <string.h>


int main()
{
    char string[100];
    printf("Enter a string line: ");
    gets(string);
    char word[25];
    printf("Enter a word: ");
    gets(word);
    int len_str = strlen(string);
    int len_word = strlen(word);
    int count;
    for (int i=0; i <= len_str-len_word; i++)
    {
        int check = 1;
        if (string[i] == word[0])
        {
            for (int j=1; j<len_word; j++)
            {
                if(string[j+i] != word[j])
                {
                    check = 0;
                    break;
                }
            }
            if (check)
            {
                printf("Occurence at index %d \n", i);
                count ++;
            }

        }

    }
    printf("Total number of occurences = %d", count);

}

//int compare(str[len_word], word[len_word], len_word)
//{
//    for (int i=0; i<
//}
