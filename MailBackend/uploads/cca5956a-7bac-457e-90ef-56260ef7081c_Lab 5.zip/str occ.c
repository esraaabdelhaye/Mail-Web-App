#include <stdio.h>
#include <string.h>


int main()
{
    char string[100];
    printf("Enter a string line: ");
    gets(string);
    char word[25];
    printf("Enter a word: ");
    gets(word);
    int len_str = strlen(string);
    int len_word = strlen(word);
    int count;
    for (int i=0; i<len_str; i++)
    {
        if (string[i] == word[0])
        {
            if (strncmp(&string[i], word, len_word) == 0)
            {
                printf("Occurence at index %d \n", i);
                count ++;
            }

        }
    }
    printf("Total number of occurence = %d", count);

}
