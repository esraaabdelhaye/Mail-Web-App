#include <stdio.h>
#include <math.h>

int get_count(int n);
int get_sum(int n, int count);

int main()
{
    int n;
    char c;
    printf("Enter the value of n: ");
    if (scanf("%d%c", &n, &c) != 2 || c != '\n')
    {
        printf("Please enter integers only.");
        return -1;
    }
    int og_n = n;
    if (n<0)
    {
        n = -n;
    }
    int count =  get_count(n);
    int sum = get_sum(n, count);
    printf("The sum of digits of %d = %d", og_n, sum);

    return 0;
}

int get_count(int n)
{
    int count;
    while (n>0)
    {
        n/=10;
        count++;
    }
    return count;
}

int get_sum(int n, int count)
{
    if (count == 0)
    {
        return 0;
    }
    else
    {
        int sum;
        int x = pow(10, count-1);
        sum = n/x + get_sum(n%x, count-1);

        return sum;
    }

}
