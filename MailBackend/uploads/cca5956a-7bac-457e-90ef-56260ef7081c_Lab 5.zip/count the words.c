#include <stdio.h>
#include <string.h>

int main()
{
    char string[100];
    printf("Enter a line of text: ");
    gets(string);
    int len = strlen(string);
    int count;
    for (int i=0; i<len; i++)
    {
        if (string[i] == ' ' || string[i] == '\t')
        {
            count ++;
        }
    }
    printf("%d words", count+1);
    return 0;
}
